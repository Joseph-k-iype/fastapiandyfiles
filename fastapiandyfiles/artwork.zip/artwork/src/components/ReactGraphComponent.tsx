/**
 * @license
 * This app exhibits yFiles for HTML functionalities.
 * Copyright (c) 2024 by yWorks GmbH, Vor dem Kreuzberg 28,
 * 72070 Tuebingen, Germany. All rights reserved.
 *
 * yFiles demo files exhibit yFiles for HTML functionalities.
 * Any redistribution of demo files in source code or binary form, with
 * or without modification, is not permitted.
 *
 * Owners of a valid software license for a yFiles for HTML
 * version are allowed to use the app source code as basis for their
 * own yFiles for HTML powered applications. Use of such programs is
 * governed by the rights and conditions as set out in the yFiles for HTML
 * license agreement. If in doubt, please mail to contact@yworks.com.
 *
 * THIS SOFTWARE IS PROVIDED ''AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
 * NO EVENT SHALL yWorks BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

import 'yfiles/yfiles.css'
import { useEffect, useRef } from 'react'
import {
  useAddGraphComponent,
  useGraphComponent,
} from './GraphComponentProvider'
import {
  CollapsibleNodeStyleDecorator,
  FoldingManager,
  GraphComponent,
  GroupNodeStyle,
  GroupNodeStyleIconType,
} from 'yfiles'
import { useGraphViewerInputMode } from '../hooks/useInputMode'
import '../lib/yFilesLicense'
import loadGraph from '../lib/loadGraph'

export default function ReactGraphComponent() {
  const graphComponent = useGraphComponent()
  const graphComponentContainer = useRef<HTMLDivElement>(null)

  if (graphComponent) {
    useAddGraphComponent(graphComponentContainer, graphComponent)
  }

  useGraphViewerInputMode(graphComponent)

  useEffect(() => {
    loadGraph().then((loadedGraph) => {
      graphComponent.graph = loadedGraph
      enableFolding(graphComponent)
      graphComponent.fitGraphBounds()
    })
  }, [])

  return (
    <div style={{ width: '100%', height: '100%' }}>
      <div
        className="graph-component-container"
        style={{ width: '100%', height: '100%' }}
        ref={graphComponentContainer}
      ></div>
    </div>
  )
}

function enableFolding(graphComponent: GraphComponent) {
  const graph = graphComponent.graph
  const groupNodeDefaults = graph.groupNodeDefaults
  if (groupNodeDefaults.style instanceof GroupNodeStyle) {
    groupNodeDefaults.style.groupIcon = GroupNodeStyleIconType.MINUS
  } else {
    groupNodeDefaults.style = new CollapsibleNodeStyleDecorator(
      groupNodeDefaults.style
    )
  }
  for (const node of graph.nodes) {
    if (graph.isGroupNode(node)) {
      if (!(node.style instanceof GroupNodeStyle)) {
        graph.setStyle(node, new CollapsibleNodeStyleDecorator(node.style))
      } else {
        node.style.groupIcon = GroupNodeStyleIconType.MINUS
      }
    }
  }

  graphComponent.graph = new FoldingManager(graph).createFoldingView().graph
}
